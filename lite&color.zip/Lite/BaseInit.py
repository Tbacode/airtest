'''
 * @Descripttion : 
 * @Author       : Tommy
 * @Date         : 2021-09-01 15:04:09
 * @LastEditors  : Tommy
 * @LastEditTime : 2021-09-03 17:46:14
'''
# -*- encoding=utf8 -*-
__author__ = "Tommy"

from airtest.core.api import *
from airtest.core.android.android import Android
from airtest.cli.parser import cli_setup
import sys
sys.path.append(r"C:\Users\talefun\Documents\airtest\Lite")


class baseInit(object):

    # 断言元素是否存在
    def assert_exists_element(self, element, ass_msg, b_time=0, a_time=0):
        sleep(b_time)
        try:
            assert_exists(element, ass_msg)
        except AssertionError as f:
            print("元素断言不存在，异常")
        sleep(a_time)

    # 断言元素是否相等
    def assert_equal_element(self, element, ass_element, ass_msg, b_time=0, a_time=0):
        sleep(b_time)
        try:
            assert_equal(element, ass_element, ass_msg)
        except AssertionError as f:
            print("元素断言不相等，异常")
        sleep(a_time)

    # 等待元素出现
    def wait_element(self, element, timeout=20, b_time=0, a_time=0):
        sleep(b_time)
        try:
            location = wait(element, timeout=timeout)
        except TargetNotFoundError as t:
            print("找不到该元素")
            location = None
        sleep(a_time)
        return location

    # 以参照物（sym_ele）寻找多个元素
    def find_element_by_symbol(self, sym_ele, *args):
        local_list = []
        if exists(sym_ele):
            for item_ele in args:
                local = self.wait_element(item_ele)
                local_list.append(local)
        return local_list

    # 游戏启动初始化
    def init(self, packagename="coloring.color.number.happy.paint.art.drawing.puzzle", flag=1):
        dev = Android()
        if flag == 1:
            print("游戏初始化清除数据")
            dev.clear_app(packagename)
            if not dev.is_locked():
                dev.unlock()
        dev.start_app(packagename)
        return dev

    # 进入成功判定
    def is_enter_home(self, flag=1, timeout=10):
        
        if flag == 1:
            sleep(timeout)
            if exists(Template(r"../tpl1629269284035.png", record_pos=(-0.001, -0.379), resolution=(1080, 1920))):
                agree_bt = self.wait_element(Template(
                    r"../tpl1629279181598.png", record_pos=(-0.004, 0.193), resolution=(1080, 1920)))
                terms_link = self.wait_element(Template(
                    r"../tpl1629279205859.png", record_pos=(-0.149, -0.012), resolution=(1080, 1920)))
                print(terms_link)
                privacy_link = self.wait_element(Template(
                    r"../tpl1629279228084.png", record_pos=(0.061, -0.013), resolution=(1080, 1920)))
                print(privacy_link)
                return agree_bt, terms_link, privacy_link
            else:
                self.is_enter_home()
        else:
            print("非首次进入判定节点进入")
            sleep(timeout)
            if not exists(Template(r"../tpl1630578345457.png", record_pos=(-0.369, -0.377), resolution=(1080, 1920))):
                timeout = 3
                self.is_enter_home(2, timeout)

    # 游戏退出,官方API会导致游戏数据写入失败，与预期不符
    def exit_game(self, b_timeout=0, a_timeout=0):
        sleep(b_timeout)
        keyevent("KEYCODE_BACK")
        sleep(2)
        yes_bt = self.wait_element(Template(r"../tpl1630659384218.png", record_pos=(0.175, 0.058), resolution=(1080, 1920)))
        if yes_bt is not None:
            touch(yes_bt)
            
            
baseObject = baseInit()




